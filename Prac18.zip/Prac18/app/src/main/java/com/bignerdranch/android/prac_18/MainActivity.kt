package com.bignerdranch.android.prac_18

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var valute: EditText
    lateinit var spinner: Spinner
    lateinit var pref: SharedPreferences
    lateinit var ed:Editor
    lateinit var saveBut:Button
    var num:Double=0.0
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        valute=findViewById(R.id.valute)
        spinner=findViewById(R.id.spinner)
        pref=getSharedPreferences("MyPref",Context.MODE_PRIVATE)
        saveBut=findViewById(R.id.save)
        ed=pref.edit()

        saveBut.setOnClickListener{
            var str:String=valute.text.toString()
            if(str.isNotEmpty()){
                num=str.toDouble()
            }
            if(valute.text.isEmpty()){
                var alertDialog=AlertDialog.Builder(this)
                    .setTitle("Info")
                    .setMessage("Пустую строку нельзя сохранить")
                    .setPositiveButton("OK",null)
                    .show()
            }
            else if(num>10000.0){
                var alertDialog=AlertDialog.Builder(this)
                    .setTitle("Info")
                    .setMessage("Не думаю что данная валюта, за свою единицу такая большая")
                    .setPositiveButton("OK",null)
                    .show()
            }
            else{
                when(spinner.selectedItem.toString()){
                    "Доллар"->{
                        ed.putString("dollar",num.toString())
                        ed.apply()
                    }
                    "Евро"->{
                        ed.putString("euro",num.toString())
                        ed.apply()
                    }
                    "Британские франки"->{
                        ed.putString("frank",num.toString())
                        ed.apply()
                    }
                    "Английские стерлинги"->{
                        ed.putString("sterling",num.toString())
                        ed.apply()
                    }
                    "Юань"->{
                        ed.putString("yan",num.toString())
                        ed.apply()
                    }
                    "Йена"->{
                        ed.putString("yena",num.toString())
                        ed.apply()
                    }
                }
                val toa=Toast.makeText(this,"Сохранено",Toast.LENGTH_SHORT)
                toa.show()
                valute.text=null
            }
        }


    }

    /*fun Save(view: View) {
        var str:String=valute.text.toString()
        if(str.isNotEmpty()){
            num=str.toDouble()
        }
        if(valute.text.isEmpty()){
            var alertDialog=AlertDialog.Builder(this)
                .setTitle("Info")
                .setMessage("Пустую строку нельзя сохранить")
                .setPositiveButton("OK",null)
                .show()
        }
        else if(num>10000.0){
            var alertDialog=AlertDialog.Builder(this)
                .setTitle("Info")
                .setMessage("Не думаю что данная валюта, за свою единицу такая большая")
                .setPositiveButton("OK",null)
                .show()
        }
        else{
            when(spinner.selectedItem.toString()){
                "Доллар"->{
                    ed.putString("dollar",num.toString())
                    ed.apply()
                }
                "Евро"->{
                    ed.putString("euro",num.toString())
                    ed.apply()
                }
                "Британские франки"->{
                    ed.putString("frank",num.toString())
                    ed.apply()
                }
                "Английские стерлинги"->{
                    ed.putString("sterling",num.toString())
                    ed.apply()
                }
                "Юань"->{
                    ed.putString("yan",num.toString())
                    ed.apply()
                }
                "Йена"->{
                    ed.putString("yena",num.toString())
                    ed.apply()
                }
            }
            val toa=Toast.makeText(this,"Сохранено",Toast.LENGTH_SHORT)
            toa.show()
            valute.text=null
        }
    }*/

    fun Next(view: View) {
        val intent=Intent(this, Diary_of_currencies::class.java)
        startActivity(intent)
    }


}