package com.bignerdranch.android.prac_18

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.*

class Diary_of_currencies : AppCompatActivity() {
    lateinit var valute: TextView
    lateinit var spinner: Spinner
    lateinit var pref: SharedPreferences
    lateinit var ed: SharedPreferences.Editor
    lateinit var outBut:Button
    lateinit var clearBut:Button
    lateinit var backBut:Button
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diary_of_currencies)
        valute=findViewById(R.id.textvalute)
        spinner=findViewById(R.id.spinner2)
        pref=getSharedPreferences("MyPref", MODE_PRIVATE)
        outBut=findViewById(R.id.output)
        ed=pref.edit()
        clearBut=findViewById(R.id.clear)
        backBut=findViewById(R.id.back)

        outBut.setOnClickListener{
            when(spinner.selectedItem.toString()) {
                "Доллар" -> {
                    if(pref.contains("dollar")) {
                        valute.text = pref.getString("dollar", "")+" Руб"
                    }
                    else{
                        var alertDialog= AlertDialog.Builder(this)
                            .setTitle("Info")
                            .setMessage("Значение еще не задано")
                            .setPositiveButton("OK",null)
                            .show()
                        valute.text = null
                    }
                }
                "Евро" -> {
                    if(pref.contains("euro"))
                        valute.text = pref.getString("euro", "")+" Руб"
                    else{
                        var alertDialog= AlertDialog.Builder(this)
                            .setTitle("Info")
                            .setMessage("Значение еще не задано")
                            .setPositiveButton("OK",null)
                            .show()
                        valute.text = null
                    }
                }
                "Британские франки" -> {
                    if(pref.contains("frank"))
                        valute.text = pref.getString("frank", "")+" Руб"
                    else{
                        var alertDialog= AlertDialog.Builder(this)
                            .setTitle("Info")
                            .setMessage("Значение еще не задано")
                            .setPositiveButton("OK",null)
                            .show()
                        valute.text = null
                    }
                }
                "Английские стерлинги" -> {
                    if(pref.contains("sterling"))
                        valute.text = pref.getString("sterling", "")+" Руб"
                    else{
                        var alertDialog= AlertDialog.Builder(this)
                            .setTitle("Info")
                            .setMessage("Значение еще не задано")
                            .setPositiveButton("OK",null)
                            .show()
                        valute.text = null
                    }
                }
                "Юань" -> {
                    if(pref.contains("yan"))
                        valute.text = pref.getString("yan", "")+" Руб"
                    else{
                        var alertDialog= AlertDialog.Builder(this)
                            .setTitle("Info")
                            .setMessage("Значение еще не задано")
                            .setPositiveButton("OK",null)
                            .show()
                        valute.text = null
                    }
                }
                "Йена" -> {
                    if(pref.contains("yena"))
                        valute.text = pref.getString("yena", "")+" Руб"
                    else{
                        var alertDialog= AlertDialog.Builder(this)
                            .setTitle("Info")
                            .setMessage("Значение еще не задано")
                            .setPositiveButton("OK",null)
                            .show()
                        valute.text = null
                    }
                }
            }
        }

        clearBut.setOnClickListener{
            ed.clear()
            ed.apply()
            valute.text = null
            val toa=Toast.makeText(this,"Очищено",Toast.LENGTH_SHORT)
            toa.show()
        }
        backBut.setOnClickListener{
            val intent=Intent(this,MainActivity::class.java)
            startActivity(intent)
        }










        /*when(spinner.selectedItem.toString()) {
            "Доллар" -> {
                if(preff.contains("dollar")) {
                    valute.text = preff.getString("dollar", "")
                }
                else{
                    var alertDialog= AlertDialog.Builder(this)
                        .setTitle("Info")
                        .setMessage("Значение еще не задано")
                        .setPositiveButton("OK",null)
                        .show()
                }
            }
            "Евро" -> {
                if(preff.contains("euro"))
                valute.text = preff.getString("euro", "")
                else{
                    var alertDialog= AlertDialog.Builder(this)
                        .setTitle("Info")
                        .setMessage("Значение еще не задано")
                        .setPositiveButton("OK",null)
                        .show()
                }
            }
            "Британские франки" -> {
                if(preff.contains("frank"))
                valute.text = preff.getString("frank", "")
                else{
                    var alertDialog= AlertDialog.Builder(this)
                        .setTitle("Info")
                        .setMessage("Значение еще не задано")
                        .setPositiveButton("OK",null)
                        .show()
                }
            }
            "Английские стерлинги" -> {
                if(preff.contains("sterling"))
                valute.text = preff.getString("sterling", "")
                else{
                    var alertDialog= AlertDialog.Builder(this)
                        .setTitle("Info")
                        .setMessage("Значение еще не задано")
                        .setPositiveButton("OK",null)
                        .show()
                }
            }
            "Юань" -> {
                if(preff.contains("yan"))
                valute.text = preff.getString("yan", "")
                else{
                    var alertDialog= AlertDialog.Builder(this)
                        .setTitle("Info")
                        .setMessage("Значение еще не задано")
                        .setPositiveButton("OK",null)
                        .show()
                }
            }
            "Йена" -> {
                if(preff.contains("yena"))
                valute.text = preff.getString("yena", "")
                else{
                    var alertDialog= AlertDialog.Builder(this)
                        .setTitle("Info")
                        .setMessage("Значение еще не задано")
                        .setPositiveButton("OK",null)
                        .show()
                }
            }
        }*/



    }
}