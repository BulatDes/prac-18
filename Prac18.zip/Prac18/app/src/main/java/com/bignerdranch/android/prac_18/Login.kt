package com.bignerdranch.android.prac_18

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.opengl.Visibility
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class Login : AppCompatActivity() {
    lateinit var loginText: EditText
    lateinit var passText: EditText
    lateinit var logBut: Button
    lateinit var regBut: Button
    lateinit var pref: SharedPreferences
    lateinit var ed: Editor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        loginText = findViewById(R.id.login)
        passText = findViewById(R.id.pass)
        logBut = findViewById(R.id.enter)
        regBut = findViewById(R.id.reg)
        pref = getPreferences(MODE_PRIVATE)
        ed = pref.edit()
        var checkLogin: String = ""
        var checkPass: String = ""
        if (pref.getString("Login", "").toString().isNotEmpty() || pref.getString("Password", "")
                .toString().isNotEmpty()
        ) {
            checkLogin = pref.getString("Login", "").toString()
            checkPass = pref.getString("Password", "").toString()
        } else {
            logBut.isEnabled=false
            val toa = Toast.makeText(this, "Зарегистрируйтесь пж сначала", Toast.LENGTH_SHORT)
            toa.show()
        }
        logBut.setOnClickListener {
            checkLogin = pref.getString("Login", "").toString()
            checkPass = pref.getString("Password", "").toString()
            if (loginText.text.toString().isEmpty() || passText.text.toString().isEmpty()) {
                val toa = Toast.makeText(this, "Введите логин или пароль", Toast.LENGTH_SHORT)
                toa.show()
            } else if (pref.getString("Login", "").toString()
                    .isNotEmpty() || pref.getString("Password", "").toString().isNotEmpty()
            ) {

                if (loginText.text.toString() == checkLogin || passText.text.toString() == checkPass) {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                } else {
                    val toa = Toast.makeText(this, "Логин или пароль неверны", Toast.LENGTH_SHORT)
                    toa.show()
                }
            }
            else{
                val toa = Toast.makeText(this, "Зарегистрируйтесь пж сначала", Toast.LENGTH_SHORT)
                toa.show()
            }


        }

        regBut.setOnClickListener{
            if (loginText.text.toString().isEmpty() || passText.text.toString().isEmpty()) {
                val toa = Toast.makeText(this, "Введите логин или пароль", Toast.LENGTH_SHORT)
                toa.show()
            } else if (loginText.toString()
                    .isNotEmpty() && passText.text.toString().isNotEmpty()
            ){
                val lt=loginText.text.toString()
                val pt=passText.text.toString()
                ed.putString("Login",lt)
                ed.putString("Password",pt)
                ed.apply()
                val toa = Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT)
                toa.show()
                logBut.isEnabled=true
            }
        }
    }
}